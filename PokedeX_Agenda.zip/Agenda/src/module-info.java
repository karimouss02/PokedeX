/**
 * 
 */
/**
 * @author Karim
 *
 */
module Agenda {
	requires java.desktop;
}